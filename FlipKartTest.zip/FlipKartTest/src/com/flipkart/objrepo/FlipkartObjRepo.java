package com.flipkart.objrepo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.flipkart.init.LaunchBrowser;

public class FlipkartObjRepo{
	
	String productName="p";
	// Login Objects
	@FindBy(how=How.XPATH,using="(//input[@type='text'])[2]")
	public WebElement UserName;
	@FindBy(how=How.XPATH,using="//input[@type='password']")
	public WebElement Password;
	@FindBy(how=How.XPATH,using="(//button[@type='submit'])[2]")
	public WebElement LoginBtn;

	
	//Logout Objects
	@FindBy(how=How.XPATH,using="//img[@title='Flipkart']")
	public WebElement FlipkartHome;
	@FindBy(how=How.XPATH,using="//div[text()='My Account']")
	public WebElement MyAccount;
	@FindBy(how=How.XPATH,using="//a[contains(.,'Logout')]")
	public WebElement LogOutLink;
	
	//Flipkart Objects
	
	@FindBy(how=How.XPATH,using="(//input[@type='text'])[1]")
	public WebElement InputItem;
	@FindBy(how=How.XPATH,using="//div[contains(text(),'Sony CyberShot DSC-W800/BC IN5')]")
	public WebElement SelectedItem;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Sony CyberShot DSC-W800/BC IN5')]")
	public WebElement ItemNameDescFromSearchPage;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Sony CyberShot DSC-W800/BC IN5')]//following::div[8]")
	public WebElement ItemPriceFromSearch;
	@FindBy(how=How.XPATH,using="//button[text()='ADD TO CART']")
	public WebElement AddToCartBtn;
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Sony CyberShot DSC-W800/BC IN5')]")
	public WebElement ItemNameFromCheckout;
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Sony CyberShot DSC-W800/BC IN5')]//following::span")
	public WebElement ItemPriceFromCheckout;
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Sony CyberShot DSC-W800/BC IN5')]//following::div")
	public WebElement ItemDescFromCheckout;
	@FindBy(how=How.XPATH,using="//span[text()='Place Order']")
	public WebElement PlaceOrderBtn;
	
		
}
