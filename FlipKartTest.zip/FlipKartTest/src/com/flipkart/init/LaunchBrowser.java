package com.flipkart.init;

import java.io.BufferedReader;
import java.io.FileReader;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.flipkart.init.ReportingConstants;
import com.flipkart.init.BrowserConstants;
import com.flipkart.init.FlipKartConstants;

import junit.framework.Assert;

public class LaunchBrowser {
	BrowserConstants browserConstants;
	ReportingConstants reportingConstants;
	FlipKartConstants flipkartConstants;
	public static WebDriver driver;
	public static String username;
	public static String password;
	public static String itemName;
	public static String productName;
	public String browser;

	public LaunchBrowser() {
		browserConstants = new BrowserConstants();
		reportingConstants = new ReportingConstants();
		flipkartConstants = new FlipKartConstants();
	}

	// This method is to fetch input values from text file
	public void readValuesFromFile() throws Exception {
		FileReader FR = new FileReader(flipkartConstants.TestFile);
		BufferedReader BR = new BufferedReader(FR);
		username = BR.readLine();
		password = BR.readLine();
		itemName = BR.readLine();
		browser = BR.readLine();
		productName = BR.readLine();
		
	}

	/**
	 * This method is to Launch browser according to the user input Creator
	 * athira.sasidharan<08/20/2019>
	 **/

	public void doLaunchBrowser() {

		try {

			if (browser.equalsIgnoreCase(browserConstants.CHROME)) {
				// Initialize chrome browser
				System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
				driver = new ChromeDriver();
				Assert.assertTrue(reportingConstants.TRUE);
				System.out.println(reportingConstants.PASS);
			} else if (browser.equalsIgnoreCase(browserConstants.FIREFOX)) {
				// Initialize firefox browser
				System.setProperty("webdriver.firefox.marionette", "./driver/geckodriver.exe");
				driver = new FirefoxDriver();
				Assert.assertTrue(reportingConstants.TRUE);
				System.out.println(reportingConstants.PASS);
			} else if (browser.equalsIgnoreCase(browserConstants.IE)) {
				// Initialize IE browser
				System.setProperty("webdriver.ie.driver", "./driver/IEDriverServer.exe");
				driver = new FirefoxDriver();
				Assert.assertTrue(reportingConstants.TRUE);
				System.out.println(reportingConstants.PASS);
			} else {
				System.out.println("No Browser is selected");
				Assert.assertFalse(true);
				System.out.println(reportingConstants.FAIL);
			}
			// Launch the browser and direct it to the Base URL
			driver.get(flipkartConstants.baseUrl);
			String url = driver.getCurrentUrl();
			// Maximize the screen
			driver.manage().window().maximize();
			// Validate the base url and the url which is launched are same
			Assert.assertEquals(flipkartConstants.baseUrl, url);
			
		} catch (Exception e) {
			throw new IllegalArgumentException();
		}
		driver=this.driver;

	}

}
