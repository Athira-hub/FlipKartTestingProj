package com.flipkart.pageobject;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.flipkart.init.LaunchBrowser;
import com.flipkart.init.ReportingConstants;
import com.flipkart.objrepo.FlipkartObjRepo;

public class Login extends LaunchBrowser{
	
	
	ReportingConstants reportingConstants;
	public WebDriver driver;
	

	public Login() throws Exception {
		reportingConstants = new ReportingConstants();
		
	}
	
	/**
	 * This method is to Login to the flipkart application
	 * Creator<athira.sasidharan> on<08/20/2019>
	 * @throws Exception 
	 **/
  
  public void doLogin() throws Exception {

	    String password = LaunchBrowser.password;
		String UserNameInput = LaunchBrowser.username;
		driver=LaunchBrowser.driver;
		// Input Username & Password in the login page
		FlipkartObjRepo pageObj=PageFactory.initElements(driver, FlipkartObjRepo.class);
		pageObj.UserName.sendKeys(UserNameInput);
		pageObj.Password.sendKeys(password);
		WebElement loginbtn = pageObj.LoginBtn;
		// Click on Login button
		if (loginbtn != null) {
			loginbtn.click();

			System.out.println("Login success..");
			System.out.println("Current User is" + UserNameInput);
			Assert.assertTrue(reportingConstants.TRUE);
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
}
