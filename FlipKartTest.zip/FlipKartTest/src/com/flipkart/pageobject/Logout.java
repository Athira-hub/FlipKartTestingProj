package com.flipkart.pageobject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.flipkart.init.LaunchBrowser;
import com.flipkart.init.ReportingConstants;
import com.flipkart.objrepo.FlipkartObjRepo;

public class Logout extends LaunchBrowser {

	ReportingConstants reportingConstants;
	public WebDriver driver;
	FlipkartObjRepo flipkartobjrepo;

	public Logout() throws IOException {
		reportingConstants = new ReportingConstants();
		flipkartobjrepo = new FlipkartObjRepo();
	}

	/**
	 * This method is to logout from the flipkart application Creator
	 * athira.sasidharan<08/20/2019>
	 **/

	public void doLogout() throws Exception {
		
		driver=LaunchBrowser.driver;
		FlipkartObjRepo pageObj=PageFactory.initElements(driver, FlipkartObjRepo.class);
		String window1=driver.getWindowHandle();
		driver.switchTo().window(window1);
		// Navigate to FlipKart Home page
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageObj.FlipkartHome); 
		 
		Actions actions = new Actions(driver);
		WebElement myAcctName = pageObj.MyAccount;
		actions.moveToElement(myAcctName).perform();
		 
		// Click on Logout
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", pageObj.LogOutLink);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		System.out.println("Logout is successful");
		Assert.assertTrue(reportingConstants.TRUE);
		driver.close();
		driver.quit();

	}
}
